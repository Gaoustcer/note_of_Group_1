# Syllabus of Assistant Teacher

## General target

* make a new group in Gitlab: Commit issue instead of using QQ
* Config VsCode of C/C++ environment
* some techique of using given IDEs to debug your program
* necessary assistance to student

## detailed Syllabus

