# 计算机网络——2020 Autumn

By Gaoustcer

Lecture given by：xinmingzhang

email xinming@ustc.edu.cn

Textbook:《计算机网络：自顶向下方法6th》

Tanebaum 计算机网络5th

新编计算机网络习题与解析 鲁士文

成绩计算：期中30% 作业10%（5次） 实验10%（4次） 期末50%

## 任务、目的和基本要求

了解计算机网络的基本原理

掌握计算机网络各层协议的基本工作原理和采用的技术

课程主页 http://staff.ustc.edu.cn/~xinming

TA:ps318716

xsh1412

ddsj

chengk

yxt95

xt795842

## The basic parameter of Network

延时，带宽，丢失率，端节点数目，服务接口，可靠性，单播/多播，实时，消息/字节流