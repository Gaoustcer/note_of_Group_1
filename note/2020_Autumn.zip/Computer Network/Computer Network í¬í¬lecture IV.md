# Computer Network ——lecture IV

## Internet协议栈

* application 支持各种网络应用
* Transport 进程-进程分组传输
* network 源主机-目的主机分组传输
* link 相邻网络设备之间分组传输
* physical 物理介质上的比特传输：信号编码

缺点：上下层依赖