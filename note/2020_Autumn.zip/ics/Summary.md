# 这是中国科学技术大学计算机系统概论2020秋季学期课程

## 老师：安虹

**office hour and Discussion:**

*(1) 4 TAs,fellow students*

*(2) Face to face help*

Questions to answer:(1)What can computer do

(2)How are they done

(3)What can't computer do

什么是计算思维

实际问题——计算系统实现

bool（true&&false）：== != && || ! < > >= <=

## Great Idea in Computer System

**Great idea0:0 and 1**

**Great idea1:Turning Computering model**:turning machines are universal

Universal Turing Machine 计算模型：Turning 结构模型：Von Neummann

theory——Practice：time cost power

ENIAC：with a Turing machine but without a Von Neummann Archeticture



