### 2020 Autumn booklist

Ramdom process：《随机过程》方兆本 60%期末+20%作业+期中20% Sheldon M.Ross

Introdution to Algorithm:《算法导论》 《Algorithm Design》 《Intro to Theory of computation》

《数值计算方法与算法》 第三版

Textbook:《计算机网络：自顶向下方法6th》